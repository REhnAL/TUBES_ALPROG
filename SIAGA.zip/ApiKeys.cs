﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Face_Recognition;

public static class ApiKeys
{
    // Isi API key Gemini kamu di antara tanda kutip.
    // Jangan upload API key ini ke GitHub / publik.
    public const string GeminiApiKey = "AQ.Ab8RN6I5chfNV15mWHk9lus4t92gmngJnh9_wGPTdqO_MtgcZg";
}

